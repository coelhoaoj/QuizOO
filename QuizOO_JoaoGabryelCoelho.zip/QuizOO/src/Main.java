import java.util.Scanner;

public class Main {
	static Scanner sc = new Scanner(System.in);
	static Usuario usuario = new Usuario();

	public static void main(String[] args) {
		cadastroUsuario();
		questoes();
		resultados();
	}

	private static void resultados() {
		System.out.println("Espero que você tenha gostado do quiz" + usuario.getNome());
		System.out.println("Quiz realizado por João.");		
	}

	private static void cadastroUsuario() {
		System.out.println("Qual é o seu Nome?");
		usuario.setNome(sc.nextLine());
		System.out.println("Em que cidade você Nasceu?");
		usuario.setCidade(sc.nextLine());		
	}

	
	private static void questoes() {

		//Questão 1
		System.out.println("\nQual foi a primeira capital do Brasil?\n");
		System.out.println("1 - Salvador\n2 - São Paulo\n3 - Rio de Janeiro\n4 - Porto Alegre");
		int q1 = sc.nextInt();
		
		//Verifica se a alternativa esta errada.
		while(q1 <1 || q1 >4) {
			System.out.println("Erro! Utilize 1, 2, 3 ou 4 para assinalar as alternativas");
			System.out.println("Reinicie o Quiz!");
			q1 = sc.nextInt();
		}
		
		//Verifica se a questão esta correta.
		if(q1 == 1) {
			System.out.println("Acertou :)");
		}else {
			System.out.println("Alternativa errada :(");
		}
		
		//Questão 2
		System.out.println("\nQuando Brasília foi escolhida como capital do Brasil?\n");
		System.out.println("1 - 1925\n2 - 1960\n3 - 1780\n4 - 1870");
		int q2 = sc.nextInt();
		
		//Verifica se a alternativa esta errada.
		while(q2 <1 || q2 >4) {
			System.out.println("Erro! Utilize 1, 2, 3 ou 4 para assinalar as alternativas.");
			System.out.println("Reinicie o Quiz!");
			q2 = sc.nextInt();
		}
		
		//Verifica se a questão esta correta.
		if(q2 == 2) {
			System.out.println("Acertou :)");
		}else {
			System.out.println("Alternativa errada :(");
		}
		
		//Questão 3
		System.out.println("\nQual é a capital de São Paulo?\n");
		System.out.println("1 - Santos\n2 - São Paulo não é um estado\n3 - Osasco\n4 - São Paulo");
		int q3 = sc.nextInt();
		
		//Verifica se a alternativa esta errada.
		while(q3 <1 || q3 >4) {
			System.out.println("Erro! Utilize 1, 2, 3 ou 4 para assinalar as alternativas.");
			System.out.println("Reinicie o Quiz!");
			q2 = sc.nextInt();
		}
		
		//Verifica se a questão esta correta.
		if(q3 == 4) {
			System.out.println("Acertou :)");
		}else {
			System.out.println("Alternativa errada :(");
		}
		
		
		//Questão 4
		System.out.println("\nQual é a capital de Santa Catarina?\n");
		System.out.println("1 - Joinville\n2 - Balneário Camboriú\n3 - Florianópolis\n4 - Pomerode");
		int q4 = sc.nextInt();
		
		//Verifica se a alternativa esta errada.
		while(q4 <1 || q4 >4) {
			System.out.println("Erro! Utilize 1, 2, 3 ou 4 para assinalar as alternativas.");
			System.out.println("Reinicie o Quiz!");
			q2 = sc.nextInt();
		}
				
		//Verifica se a questão esta correta.
		if(q4 == 3) {
			System.out.println("Acertou :)");
		}else {
			System.out.println("Alternativa errada :(");
		}
		
		
		//Questão 5
		System.out.println("\nQual é a capital do Rio Grande do Norte?\n");
		System.out.println("1 - Natal\n2 - Manaus \n3 - Rondonia\n4 - Alagoas");
		int q5 = sc.nextInt();
		
		//Verifica se a alternativa esta errada.
		while(q5 <1 || q5 >4) {
			System.out.println("Erro! Utilize 1, 2, 3 ou 4 para assinalar as alternativas.");
			System.out.println("Reinicie o Quiz!");
			q2 = sc.nextInt();
		}
				
		//Verifica se a questão esta correta.
		if(q5 == 1) {
			System.out.println("Acertou :)");
		}else {
			System.out.println("Alternativa errada :(");
		}
		
		
		//Questão 6
		System.out.println("\nQual é a capital do Tocantins?\n");
		System.out.println("1 - Rondonia \n2 - Manaus \n3 - Palmas\n4 - Porto Alegre");
		int q6 = sc.nextInt();
		
		//Verifica se a alternativa esta errada.
		while(q6 <1 || q6 >4) {
			System.out.println("Erro! Utilize 1, 2, 3 ou 4 para assinalar as alternativas.");
			System.out.println("Reinicie o Quiz!");
			q2 = sc.nextInt();
		}
				
		//Verifica se a questão esta correta.
		if(q6 == 3) {
			System.out.println("Acertou :)");
		}else {
			System.out.println("Alternativa errada :(");
		}
		
		//Questão 7
		System.out.println("Questão de Verdadeiro (V) e Falso (F) sobre o Brasil\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "( ) O Ano que foi proclamado a Independência do Brasil foi em 1822.\r\n"
				+ "\r\n"
				+ "( ) O primeiro presidente do Brasil foi Floreano Peixoto\r\n"
				+ "\r\n"
				+ "( ) Pero Vaz de Caminha construiu Brasília.\r\n"
				+ "\r\n"
				+ "( ) Tiradentes foi um dos participantes da Inconfidência Mineira\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "Assinale a sequência correta de Verdadeiro e Falso:");
		System.out.println("1 - V, F, F, V.\n2 - V, V, V, F.\n3 - V, F, F, f.\n4 - F, F, f, F.\n");
		int q7 = sc.nextInt();

		//Verifica se a alternativa esta errada.
		while(q7 <1 || q7 >4) {
			System.out.println("Erro! Utilize 1, 2, 3 ou 4 para assinalar as alternativas.");
			System.out.println("Reinicie o Quiz!");
			q7 = sc.nextInt();
		}
		
		//Verifica se a questão esta correta.
		if(q7 == 1) {
			System.out.println("Acertou :)");
		}else {
			System.out.println("Alternativa errada :(");
		}
		
		//Questão 8
		System.out.println("\nQual é a Região que o Amapá está Situado?\n");
		System.out.println("1 - Centro-Oeste \n2 - Sudeste \n3 - Nordeste\n4 - Norte");
		int q8 = sc.nextInt();
		
		//Verifica se a alternativa esta errada.
		while(q8 <1 || q8 >4) {
			System.out.println("Erro! Utilize 1, 2, 3 ou 4 para assinalar as alternativas.");
			System.out.println("Reinicie o Quiz!");
			q2 = sc.nextInt();
		}
				
		//Verifica se a questão esta correta.
		if(q8 == 4) {
			System.out.println("Acertou :)");
		}else {
			System.out.println("Alternativa errada :(");
		}
		
		//Questão 9
		System.out.println("\nQual é a Região que o Amapá está Situado?\n");
		System.out.println("1 - Centro-Oeste \n2 - Sudeste \n3 - Nordeste\n4 - Norte");
		int q9 = sc.nextInt();
		
		//Verifica se a alternativa esta errada.
		while(q9 <1 || q9 >4) {
			System.out.println("Erro! Utilize 1, 2, 3 ou 4 para assinalar as alternativas.");
			System.out.println("Reinicie o Quiz!");
			q2 = sc.nextInt();
		}
				
		//Verifica se a questão esta correta.
		if(q9 == 4) {
			System.out.println("Acertou :)");
		}else {
			System.out.println("Alternativa errada :(");
		}
		
		//Questão 10
		System.out.println("\nQual é a capital do Amapá?\n");
		System.out.println("1 - Pernambuco \n2 - Bahia \n3 - Macapá\n4 - Fortaleza");
		int q10 = sc.nextInt();
		
		//Verifica se a alternativa esta errada.
		while(q10 <1 || q10 >4) {
			System.out.println("Erro! Utilize 1, 2, 3 ou 4 para assinalar as alternativas.");
			System.out.println("Reinicie o Quiz!");
			q10 = sc.nextInt();
		}
				
		//Verifica se a questão esta correta.
		if(q10 == 3) {
			System.out.println("Acertou :)");
		}else {
			System.out.println("Alternativa errada :(");
		}
	}
}
